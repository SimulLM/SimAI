"""Package an independent review only after all scheduled processes finish."""
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RUN_ID = '20261119-phase8-independent-acceptance-01'
OUT = ROOT / 'results/dag/phase8' / RUN_ID
DOC = ROOT / 'docs/dag/phase8/acceptance'


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    before, after = read(OUT/'identity-before.json'), read(OUT/'identity-after.json')
    assert after['tested_commit']['stdout'].strip()==before['tested_commit'], 'HEAD changed during acceptance'
    assert after['branch']['stdout']==before['branch']['stdout'], 'branch changed during acceptance'
    historical = read(OUT/'historical-audit.json')
    independent = read(OUT/'independent-output-audit.json')
    initial_full = read(OUT/'full/acceptance-report.json')
    full = read(OUT/'formal-recheck/acceptance-report.json')
    dense = read(OUT/'dense/simulation-report.json')
    dense_costs = read(OUT/'dense-cost-source-audit.json')
    with (OUT/'dense/request-comparison.csv').open(encoding='utf-8', newline='') as stream:
        validation = [r for r in csv.DictReader(stream) if r['split']=='validation']
    dense_metrics = {}
    for metric, suffix in (('request_e2e','s'),('ttft','ttft_s'),('tpot','tpot_s')):
        errors = {mode:[abs(float(r[mode+'_'+suffix])-float(r['reference_'+suffix]))/abs(float(r['reference_'+suffix])) for r in validation]
                  for mode in ('old','same_cost','revised_cost')}
        dense_metrics[metric] = {'samples':len(validation),
            'mean_relative_error':{m:math.fsum(v)/len(v) for m,v in errors.items()},
            'outcomes':{outcome:sum(('tied' if abs(old-new)<=1e-12 else 'improved' if old>new else 'regressed')==outcome
                for old,new in zip(errors['old'],errors['revised_cost'])) for outcome in ('improved','tied','regressed')}}
    save(OUT/'dense-independent-metrics.json',dense_metrics)
    replay = read(OUT/'formal-recheck/reproduction-report.json')
    formal_manifest = read(OUT/'formal-recheck/run-manifest.json')
    tool_key = 'docs/dag/phase8/acceptance/review.py'
    tested_tool = OUT/'review-tools/review-before-encoding-fix.py'
    assert sha(tested_tool)==formal_manifest['source_sha256'][tool_key], 'Missing exact auditor helper snapshot from formal run'
    assert not after['changed_tested_files'], after['changed_tested_files']
    families = {}
    for name in ('original', 'expanded', 'holdout'):
        families[name] = {
            'submission':read(OUT/(name+'-submission')/'mechanism-report.json'),
            'fcfs':read(OUT/(name+'-fcfs')/'mechanism-report.json'),
            'comparison':read(OUT/(name+'-comparison')/'comparison-report.json')}
    comparisons = [f['comparison'] for f in families.values()]
    regression = full.get('regression', {})
    operations = {p.parent.name:read(p) for p in (OUT/'operations').glob('*/process-result.json')}
    wsl_identity = read(OUT/'wsl-git-identity.json')
    wsl_diagnostic = read(OUT/'wsl-text-diff-diagnostic.json')
    env = {'base_python':'D:/Environment/Python312/python.exe', 'version':before['python'],
           'machine':read(OUT/'operations/machine-description/process.log'),
           'platform':before['platform'], 'venvs':{}, 'wsl':{
               'distribution':'Ubuntu-22.04','repository':'/mnt/g/github/SimAI',
               'log':'build/wsl-environment.log', 'build_inputs_log':'build/build-inputs.log',
               'git_identity':{name:dict(head=r['head']['stdout'].strip(),raw_status_exit_code=r['status']['exit_code'],
                    raw_status_lines=len(r['status']['stdout'].splitlines())) for name,r in wsl_identity.items()},
               'raw_git_identity_evidence':'wsl-git-identity.json',
               'text_diff_diagnostic':wsl_diagnostic,
               'build_status':(OUT/'build/build-status.txt').read_text(),
               'binary_sha256':(OUT/'build/binaries.sha256').read_text()},
           'fresh_reference':read(OUT/'dense/backend-reference/backend-manifest.json'),
           'timing_note':'Three scale runs and backpressure completed before concurrent mechanism runs. Mechanism runs overlapped with regression/replay and each other; their wall times are not isolated performance benchmarks.'}
    for name in ('env-a','env-b'):
        folder=ROOT/'.cache/phase8-acceptance-20261119'/name
        env['venvs'][name]={'path':str(folder),'configuration':(folder/'pyvenv.cfg').read_text(),
             'pip_freeze':(OUT/'operations'/('freeze-'+name)/'process.log').read_text(),
             'pip_check':operations['check-'+name]}
    sections = {
        'historical_evidence_integrity':dict(status='passed' if historical['passed'] else 'failed',
            archives=len(historical['archives']), internal_hashes_checked=sum(r['internal_hashes_checked'] for r in historical['archives']),
            source_hashes_checked=sum(r['source_hashes_checked'] for r in historical['archives'])),
        'full_regression':dict(status='passed' if regression.get('exit_code')==0 else 'failed',result=regression),
        'joint_functionality':dict(status=full['functional_status'], cases=full['joint_cases']),
        'scale_overhead':dict(status='passed' if all(r['passed'] for r in full['joint_cases'][:3]) else 'failed', file='full/scale-overhead.csv'),
        'same_cost_mechanism':dict(status='passed' if all(f['fcfs']['status']=='passed' and f['comparison']['passed'] and f['submission']['functional_status']=='passed' for f in families.values()) else 'failed',
            request_evaluations=sum(c['requests'] for c in comparisons),cases=sum(len(f['fcfs']['cases']) for f in families.values()),
            relative_to_submission={key:sum(c.get('vs_previous_all',{}).get(key,0) for c in comparisons) for key in ('improved','tied','regressed')},
            primary_reference='Independent Decimal FCFS queue; synthetic fixed compute/communication costs; zero fit parameters'),
        'controlled_dense_accuracy':dict(status=dense['status'],reference_nature='simulated',validation_samples=dense['validation_samples'],
            old_mean_relative_error=dense['old_mean_relative_error'],same_cost_mean_relative_error=dense['same_cost_mean_relative_error'],
            revised_mean_relative_error=dense['revised_mean_relative_error'],outcomes=dense['outcomes'],attribution='Communication cost calibration',independently_recomputed_metrics=dense_metrics),
        'dense_cost_provenance':dict(status='passed' if dense_costs['passed'] else 'failed',evidence='dense-cost-source-audit.json',
            raw_collectives_checked=dense_costs['raw_collectives_checked'],executed_tp_tasks_checked=dense_costs['executed_tp_tasks_checked']),
        'fresh_environment_replay':dict(status=replay['status'],report='formal-recheck/reproduction-report.json'),
        'independent_artifact_invariants':{k:v for k,v in independent.items() if k!='cases'},
        'tested_source_unchanged':dict(status='passed',tracked_files=len(before['source_sha256']),changed=[]),
        'wsl_checkout_diagnostic':dict(status='passed' if all(r['exit_code']==0 for r in wsl_diagnostic.values()) else 'needs_review',
            raw_status='preserved separately, not byte-clean',diagnostic=wsl_diagnostic,
            backend_source='Locked Git archives, not uncommitted WSL worktree files'),
        'full_scope_accuracy':dict(status='blocked',official_dataset='configs/dag/phase8/validation.json',
            required_scenarios=['dense','pd','moe','joint'],reason='Official dataset is empty. Controlled dense samples do not cover PD/MoE/joint.'),
        'hardware_accuracy':dict(status='not_validated',reason='CPU simulation/queue references; no matching GPU request measurements.'),
        'independent_person_signoff':dict(status='pending_external_signoff',reason='Executed by Codex automated reviewer; no natural-person signature claimed.')}
    available_passed = (historical['passed'] and regression.get('exit_code')==0 and full['functional_status']=='passed'
        and sections['same_cost_mechanism']['status']=='passed' and dense['status']=='passed' and dense_costs['passed'] and replay['status']=='passed' and independent['passed'])
    report={'schema_version':'1.0','run_id':RUN_ID,'review_branch':before['branch']['stdout'].strip(),
        'tested_commit':before['tested_commit'],'reviewer':'Codex automated acceptance',
        'created_at':datetime.now().astimezone().isoformat(),'overall_project_acceptance':'pending' if available_passed else 'failed',
        'available_scope_acceptance':('passed' if all(r['exit_code']==0 for r in wsl_diagnostic.values()) else 'passed_with_limitations') if available_passed else 'failed',
        'sections':sections,'evidence_type':'New runs distinguished from historical archive verification',
        'formal_entry_exit_code':full['exit_code'],'hardware_accuracy_claim':False,
        'formal_entry_evidence':'formal-recheck/acceptance-report.json',
        'initial_formal_entry':dict(exit_code=initial_full['exit_code'],regression=initial_full.get('regression'),
            evidence='full/acceptance-report.json',disposition='Retained failure. Windows path length diagnosed by short-path test; complete formal entry rerun at a shorter output path without code changes.'),
        'source_identity_note':'Acceptance documents are added after the tested commit. Product sources/configurations/tests remain unchanged.',
        'operation_results':operations,'artifact':f'artifacts/{RUN_ID}.zip',
        'auditor_tool_provenance':{'tested_review_py_sha256':sha(tested_tool),
            'tested_snapshot':'review-tools/review-before-encoding-fix.py',
            'final_review_py_sha256':sha(DOC/'review.py'),'change':'Post-run explicit UTF-8 checkpoint decoding only'},
        'audit_tool_notes':['Auditor checkpoint originally read UTF-8 identity JSON using Windows default GBK. Fixed only the new auditor helper after formal runs; original helper and error record retained. Product code/tests/configurations unchanged.',
            'Raw WSL Git status includes checkout differences; see explicit EOL/filemode diagnostic. Normalization is not a raw hash match. Backends were built from locked Git archives.'],
        'known_execution_issues':['Initial sandbox DNS failure; retried authorized installation succeeded in both clean environments.',
          'Initial complete regression: 312 passed, one Windows 261-character evidence path failed. Short-path diagnostic passed; complete formal acceptance rerun preserved separately.',
          'Windows sandbox cannot fully inspect submodule Git metadata; WSL submodule identities and build-input logs retained.',
          'WSL root/SimCCL/aicb content diagnostics passed ignoring EOL/filemode; ns-3 working-tree diagnostic timed out after 180s. Raw status retained. Reference binary was built from the locked ns-3 Git archive, not this working tree.',
          'WSL shell status side-files were empty; not treated as backend success evidence. Complete generated manifests/raw outputs and dense validation independently checked.']}
    save(DOC/'acceptance-report.json', report)
    save(DOC/'environment.json',env)
    problems = '''# 第八阶段独立验收问题与边界

## 阻塞整体签收

1. **完整范围精度尚缺参考。** 正式四场景 validation 配置为空；本轮 dense 模拟参考与 FCFS 排队对照不能替代 PD/MoE/joint 精度。补齐匹配记录、冻结参数后重跑正式入口。
2. **另一人复现确认仍待完成。** 本轮由 Codex 自动化验收，已执行两个隔离环境；没有替自然人签署复现确认。实际验收人应记录操作者、固定提交、命令及结果。

## 结论适用范围

- dense 校准结果相对 ns-3 通信参考；计算画像与调度器共享，不证明计算、调度或硬件真实性。
- FCFS 结果只证明固定费用、端点串行服务假设下的资源排队建模；默认 submission 保持原行为，启用 FCFS 必须匹配目标假设。
- 完整回归和联合功能通过不推导全部配置支持。联合范围沿用 TP=1、PP=1、同构 P/D 与显式 EP 组。
- 多资源 FCFS 是工作保持派发，不保证任意系统等价于每个资源的严格预约队列。

## 保留的执行记录

- **Windows 路径长度复现问题。** 首轮完整回归 312 通过、1 失败，归档复制路径长 261 字符，触发 FileNotFoundError。短路径定向复测通过后，在较短输出目录重跑整个正式入口，不修改源代码、测试或输入。原始失败、定向诊断、完整复跑均保留。这是可复现性限制，交付方宜提供短临时路径配置或明确路径长度要求。
- 首次安装遇到沙箱网络解析失败，日志保留；联网重试成功，没有借用旧依赖路径。
- 历史源码与当前工作区的原始字节差异单列，换行诊断不等同字节哈希匹配。历史归档内部哈希独立核验。
- WSL 原始 Git 状态显示大量修改；逐仓库以只读 diff 显式忽略行尾 CR 和文件模式进行诊断，结果保存在 wsl-text-diff-diagnostic.json，不把它改写成原始字节 clean。后端从锁定 Git archive 构建。
- 根仓库、SimCCL、aicb 的上述差异诊断返回 0；ns-3 工作树内容诊断超过 180 秒，保持 needs_review，不能声称该工作树 clean。本轮 ns-3 二进制从锁定提交的 archive 构建，构建日志、源码版本与二进制哈希已记录，因此此额外诊断未替代或改变实际被测后端身份。
- 验收工具自身的 checkpoint 曾因 Windows 默认 GBK 读取 UTF-8 身份文件失败；只修正新增验收工具的编码，保留旧工具快照和错误记录，不属于交付实现缺陷。
- 机制实验并发执行，其墙钟不作为独立开销基线；三档规模与背压先单独完成。
- WSL shell 状态旁文件为空，未据此判断后端通过；保留工具完成记录、实际构建状态、后端完整 manifest 和原始 CSV，并由 dense 流程再次核验。
'''
    (DOC/'findings.md').write_text(problems,encoding='utf-8')
    scaled=list(csv.DictReader((OUT/'full/scale-overhead.csv').open(encoding='utf-8')))
    table='\n'.join(f"| {r['request_count']} | {r['task_count']} | {r['event_count']} | {float(r['wall_time_s']):.2f} | {int(r['peak_rss_bytes'])/1024**2:.2f} | {r['event_queue_peak']} |" for r in scaled)
    mechanism=sections['same_cost_mechanism']
    text=f'''# 第八阶段独立验收

本轮在 **{report['review_branch']}** 分支执行，被验收提交为 `{report['tested_commit']}`。
执行者为 **Codex 自动化验收**；新增验收文档不改变被测版本，没有修改交付实现、费用、测试或冻结输入，也没有自动提交或推送。

**结论：已有范围的功能、开销、有限范围模拟精度与环境重放分别验收；项目总体验收仍 pending。**

| 项目 | 本轮结果 |
|---|---|
| 五个历史包、内部产物及源码快照 | {sections['historical_evidence_integrity']['status']}；重算历史误差表 |
| 阶段一至八完整回归 | {regression.get('tests')} 项，failures={regression.get('failures')}，errors={regression.get('errors')}，skipped={regression.get('skipped')} |
| 原 CLI 联合执行／背压 | {full['functional_status']}；费用结算、KVReady、资源清理均检查 |
| 同费用机制与 FCFS | {mechanism['status']}；{mechanism['cases']} 场景、{mechanism['request_evaluations']} 请求评估；相对 submission：{mechanism['relative_to_submission']} |
| 新后端 dense 参考 | {dense['status']}；验证 E2E 平均相对误差 {dense['old_mean_relative_error']:.4%} → {dense['revised_mean_relative_error']:.4%} |
| dense 费用来源独立核验 | {dense_costs['raw_collectives_checked']} 条原始 collective、{dense_costs['executed_tp_tasks_checked']} 个实际 TP 任务；单位换算及冻结 offset 均通过 |
| 第二隔离环境重放 | {replay['status']}；模拟时间容差 1e-12 秒 |
| 独立输出审计 | {independent['cli_outputs']} 份 CLI 输出、{independent['graphs']} 图、{independent['tasks']} 任务，passed={independent['passed']} |
| WSL 工作树差异诊断 | 根仓库／SimCCL／aicb 忽略行尾与模式后无差异；ns-3 诊断超时，保留 needs_review；后端使用锁定 archive 构建 |
| 正式四场景精度 | blocked；默认验证数据仍为空 |
| 真实硬件精度／自然人签字 | 未验证／待确认 |

正式入口退出 `{full['exit_code']}`，表示功能通过、综合精度仍阻塞，不能据局部实验标全部验收通过。
首轮正式入口退出 `{initial_full['exit_code']}`：312 通过、1 个 Windows 路径长度失败；短路径诊断通过后完整复跑，以上回归结论采用复跑结果。原失败位于 full/，复跑归档于 formal-recheck/；原始复跑目录和搬运说明见 formal-recheck-location.json。
dense 同费用 DAG 与旧路径一致，收益来自费用校准；FCFS 实验保持费用不变，独立说明资源排队机制的贡献。
既有场景属于回归数据；新增场景的输入冻结覆盖不等于新的物理参考或硬件验证。

## 本机规模记录

| 请求数 | 任务数 | 宿主事件数 | 墙钟/s | RSS峰值/MiB | 队列峰值 |
|---:|---:|---:|---:|---:|---:|
{table}

以上是本机实际测量，不对其他机器承诺墙钟一致。规模与背压测量先完成，随后机制实验与回归并发。

## 证据与复现

- [结构化验收报告](acceptance-report.json)、[环境](environment.json)、[问题和边界](findings.md)。
- [正式证据包](artifacts/{RUN_ID}.zip)，校验和见 [SHA256SUMS](artifacts/SHA256SUMS)。ZIP 内保存原始运行、全部命令／日志、测试 XML、构建日志、后端 CSV、冻结参数、图／时间线及 SHA-256 manifest。
- 原始目录：`results/dag/phase8/{RUN_ID}/`，受 Git 忽略。ZIP 排除虚拟环境、可重建预测缓存和 pytest 临时目录。
- 历史交付包保持原样，位于上一层 artifacts。本轮 historical-audit 记录精确哈希及重算结果；不以历史运行替代新运行。

在仓库根目录执行下列步骤；复验必须使用新的 run_id 和 cache 目录，不能覆盖本轮。

```powershell
$base = 'D:/Environment/Python312/python.exe'
$run = 'results/dag/phase8/YYYYMMDD-phase8-independent-acceptance-NN'
$cache = '.cache/phase8-acceptance-new'
$formal = 'results/dag/phase8/YYYYMMDD-p8-check-NN'
& $base docs/dag/phase8/acceptance/review.py init --run $run --cache $cache
& $base docs/dag/phase8/acceptance/review.py audit --run $run --cache $cache
& $base docs/dag/phase8/acceptance/review.py environment --run $run --cache $cache
& $base docs/dag/phase8/acceptance/review.py prepare-dense --run $run --cache $cache
# 按交付方 SIMULATED_REFERENCE.md，在 WSL 新构建并生成参考；仓库路径为 /mnt/g/github/SimAI。
# 后端输出放到 $run/dense/backend-reference；本轮实际命令在 ZIP 的 build/ 中。
& $base docs/dag/phase8/acceptance/review.py score-dense --run $run --cache $cache
# Windows 使用短正式输出路径，避免测试内部再嵌套历史路径后超过 260 字符。
& "$cache/env-a/Scripts/python.exe" scripts/dag_phase8/main.py --output $formal --repro-python "$cache/env-b/Scripts/python.exe"
# 保留原目录；复制到总证据目录方便归档，报告中记录真实运行路径。
Copy-Item -LiteralPath $formal -Destination "$run/formal-recheck" -Recurse
& $base docs/dag/phase8/acceptance/review.py mechanism --run $run --cache $cache
& $base docs/dag/phase8/acceptance/audit_outputs.py --run $run
& $base docs/dag/phase8/acceptance/review.py checkpoint --run $run --cache $cache
```

`review.py` 是记录型编排器：每个操作的退出码在 operations/*/process-result.json；顶层 Python 正常返回不等于所有子操作通过。
完整门槛由正式报告分项判断。安装失败、缺失 manifest 或任何功能失败不能计为通过。
本轮完整环境 freeze、子模块身份和二进制哈希见证据包及 environment.json。自然人签字仍需实际操作者确认。
'''
    (DOC/'README.md').write_text(text,encoding='utf-8')
    for name in ('README.md','acceptance-report.json','environment.json','findings.md','review.py','audit_outputs.py'):
        target=OUT/'review-documentation'/name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(DOC/name,target)
    shutil.copyfile(Path(__file__),OUT/'review-documentation/finalize.py')
    excluded={'pytest-tmp','retry-pytest-tmp','predictor-cache','prediction-cache','__pycache__'}
    files=[p for p in OUT.rglob('*') if p.is_file() and not any(part in excluded or 'pytest-tmp' in part for part in p.relative_to(OUT).parts)]
    manifest={'run_id':RUN_ID,'tested_commit':before['tested_commit'],'review_branch':report['review_branch'],
        'excluded_directories':sorted(excluded),'artifact_sha256':{p.relative_to(OUT).as_posix():sha(p) for p in sorted(files)}}
    save(OUT/'review-manifest.json',manifest)
    files.append(OUT/'review-manifest.json')
    archive=DOC/'artifacts'/(RUN_ID+'.zip')
    archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(files):z.write(p,RUN_ID+'/'+p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,h in manifest['artifact_sha256'].items():
            assert hashlib.sha256(z.read(RUN_ID+'/'+name)).hexdigest()==h,name
    (archive.parent/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n',encoding='utf-8')
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(files),'sections':{k:v.get('status',v.get('passed')) for k,v in sections.items()}},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
