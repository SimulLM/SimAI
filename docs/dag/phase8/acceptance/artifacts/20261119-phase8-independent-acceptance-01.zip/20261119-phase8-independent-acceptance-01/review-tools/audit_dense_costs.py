"""Independently check raw backend microseconds against executed TP task costs."""
import csv
import json
import math
from pathlib import Path
import sys

root = Path(sys.argv[1])
frozen = json.loads((root/'inputs/frozen-inputs.json').read_text())
offset = json.loads((root/'calibration.json').read_text())['tp_cost_calibration']['offset_s']
base = {}
errors = []
backend_rows = 0
for path in (root/'backend-reference').glob('*/*/collective.json'):
    item = json.loads(path.read_text())
    table = list(csv.reader((path.parent/item['csv']).read_text().splitlines()))
    header = next(i for i,row in enumerate(table) if row and row[0].strip()=='layer_name')
    column = table[header].index(item['column'])
    values = [float(row[column]) for row in table[header+1:] if row and row[0].startswith('layer')]
    if item['unit']!='us' or values!=item['values'] or len(values)!=1:
        errors.append(str(path)+' raw unit/value mismatch')
    backend_rows += len(values)
    if item['backend']=='analytical':
        base[frozen['payload_bytes'][item['case']]] = values[0]*1e-6
checked = 0
for role in ('same_cost','revised_cost'):
    for path in (root/'runs').glob('*/'+role+'/cli/*/cost-breakdown.csv'):
        with path.open(encoding='utf-8',newline='') as stream:
            for row in csv.DictReader(stream):
                if row['op'] not in ('attention.tp','mlp.tp'):
                    continue
                metadata = json.loads(row['metadata'])
                expected = base[metadata['payload_bytes']] + (offset if role=='revised_cost' else 0)
                duration = float(row['duration_s'])
                if not math.isclose(duration, expected, abs_tol=1e-12, rel_tol=1e-10):
                    errors.append(str(path)+' '+row['task_id']+' backend cost mismatch')
                if not math.isclose(float(row['raw_value'])*float(row['conversion_to_s']),duration,abs_tol=1e-12):
                    errors.append(str(path)+' '+row['task_id']+' conversion mismatch')
                if row['source']!='simai_analytical.ExecutionTime':
                    errors.append(str(path)+' unexpected source '+row['source'])
                checked += 1
result = dict(passed=not errors and checked>0, raw_collectives_checked=backend_rows,
              executed_tp_tasks_checked=checked, tolerance_s=1e-12, errors=errors,
              note='Raw CSV unit us -> seconds; task ledger ms -> seconds. Revised tasks add only calibration-group frozen offset.')
(root.parent/'dense-cost-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(0 if result['passed'] else 1)
