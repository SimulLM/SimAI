"""Read fixed Git/submodule identities using Linux Git, preserving failures."""
import json
from pathlib import Path
import subprocess

root = Path('/mnt/g/github/SimAI')
result = {}
for name in ('.', 'SimCCL', 'aicb', 'ns-3-alibabacloud'):
    result[name] = {}
    for key, args in (('head', ['rev-parse','HEAD']), ('status', ['status','--short'])):
        p = subprocess.run(['git','-C',str(root/name),*args],capture_output=True,text=True)
        result[name][key] = dict(exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
path = Path(__file__).resolve().parents[1]/'wsl-git-identity.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
