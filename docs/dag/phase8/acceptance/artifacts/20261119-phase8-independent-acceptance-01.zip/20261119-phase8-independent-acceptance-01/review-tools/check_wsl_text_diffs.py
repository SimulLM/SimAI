"""Diagnose WSL/Windows checkout differences without changing Git config."""
import json
from pathlib import Path
import subprocess

root = Path('/mnt/g/github/SimAI')
results = {}
for name in ('.', 'SimCCL', 'aicb', 'ns-3-alibabacloud'):
    argv = ['git','-c','core.filemode=false','-C',str(root/name),'diff',
            '--ignore-cr-at-eol','--ignore-submodules=all','--quiet','HEAD','--']
    try:
        p = subprocess.run(argv,capture_output=True,text=True,timeout=180)
        results[name] = dict(argv=argv,exit_code=p.returncode,stderr=p.stderr,
            interpretation='No tracked content difference after explicitly ignoring CR-at-EOL and filemode; raw WSL status remains preserved.' if p.returncode==0 else 'Requires investigation; not normalized to passed.')
    except subprocess.TimeoutExpired:
        results[name] = dict(argv=argv,exit_code=None,error='timeout after 180 seconds')
(Path(__file__).resolve().parents[1]/'wsl-text-diff-diagnostic.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({name:r['exit_code'] for name,r in results.items()}))
