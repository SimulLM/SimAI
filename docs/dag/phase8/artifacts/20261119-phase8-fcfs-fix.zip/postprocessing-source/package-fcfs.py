from pathlib import Path
import hashlib,json,zipfile

root=Path(__file__).resolve().parents[1]
artifact=root/'docs/dag/phase8/artifacts/20261119-phase8-fcfs-fix.zip'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime=root/'.cache/phase8-fcfs-tested-source-01'
snapshot=json.loads((runtime/'snapshot-manifest.json').read_text())
files={}
def add(p,name=None):
    name=name or p.relative_to(root).as_posix()
    assert name not in files
    files[name]=p
def tree(p,prefix=None):
    for f in p.rglob('*'):
        if f.is_file():add(f,(prefix+'/'+f.relative_to(p).as_posix()) if prefix else None)
runs={key:root/('results/dag/phase8/20261119-fcfs-'+key+'-01') for key in ('expanded','original','holdout','holdout-submission')}
for key,p in runs.items():
    manifest=json.loads((p/'run-manifest.json').read_text())
    for name,value in manifest['source_sha256'].items():
        assert snapshot[name]==value and digest(runtime/name)==value
    for name,value in manifest['artifact_sha256'].items():assert digest(p/name)==value
    tree(p)
    add(root/('.cache/phase8-fcfs-'+key+'-01.log'),'console/'+key+'.log')
for key in ('expanded','original','holdout'):
    p=root/('results/dag/phase8/20261119-fcfs-'+key+'-comparison-01')
    assert json.loads((p/'comparison-report.json').read_text())['passed']
    tree(p)
tree(root/'results/dag/phase8/20261119-fcfs-display-01')
tree(root/'results/dag/phase8/20261119-fcfs-verification-01')
for name,value in snapshot.items():
    p=runtime/name;assert digest(p)==value;add(p,'tested-source/'+name)
add(runtime/'snapshot-manifest.json','tested-source/snapshot-manifest.json')
for name in ('queue_policy_comparison.py','fcfs_comparison_display.py'):
    p=root/'scripts/dag_phase8'/name;add(p,'postprocessing-source/scripts/dag_phase8/'+name)
for name in ('DAG_FCFS_FIX.md','README.md','ACCEPTANCE.md','DAG_MECHANISM_EXPANDED.md'):
    add(root/'docs/dag/phase8'/name)
for suffix in ('png','svg','pdf'):add(root/('docs/dag/phase8/figures/dag-fcfs-fix.'+suffix))
for name in ('dag-fcfs-fix.html','dag-fcfs-fix-manifest.json'):add(root/'docs/dag/phase8/artifacts'/name)
add(root/'configs/dag/phase8/mechanism-fcfs-holdout.json')
add(root/'.cache/phase8-fcfs-holdout.json','inputs/original-holdout-spec.json')
add(Path(__file__),'postprocessing-source/package-fcfs.py')
for name in ('test-evidence-63c36b21e96a40e282da5b18eaa5b5df','test-evidence-6fcb4f7743bb4e92aa3514000f1868b7'):
    tree(root/'results/dag/phase4'/name)
primary=runs['expanded'].relative_to(root).as_posix()
delivery=dict(result_path=primary,manifest_sha256=digest(runs['expanded']/'run-manifest.json'),
    result_paths={k:p.relative_to(root).as_posix() for k,p in runs.items()},
    runtime_source_snapshots='tested-source/',postprocessing_sources='postprocessing-source/',
    source_note='Runtime snapshots are the exact files scanned during simulation/tests. Comparison CSV normalization and the display renderer were finalized after simulations; their final sources are recorded separately.',
    hardware_accuracy_claim=False,primary_reference='unchanged FCFS simulation',
    request_evaluations=466,scenarios=38,cli_executions_in_four_experiments=96,
    artifact_sha256={name:digest(p) for name,p in files.items()})
with zipfile.ZipFile(artifact,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('DELIVERY.json',json.dumps(delivery,indent=2)+'\n')
with zipfile.ZipFile(artifact) as z:
    assert z.testzip() is None
    for name,value in delivery['artifact_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==value
sha=digest(artifact)
checksum=root/'docs/dag/phase8/artifacts/SHA256SUMS'
with checksum.open('a',encoding='utf-8',newline='\n') as stream:stream.write(sha+'  '+artifact.name+'\n')
print(json.dumps(dict(archive=str(artifact.relative_to(root)),sha256=sha,bytes=artifact.stat().st_size,files=len(files)+1,snapshots=len(snapshot))))
