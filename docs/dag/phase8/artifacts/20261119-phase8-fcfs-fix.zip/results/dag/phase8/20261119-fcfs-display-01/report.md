# FCFS 排队策略修复实验

原生、修复前 DAG 与修复后 DAG 使用相同服务费用。主要参考始终为独立 FCFS 模拟。

| 数据集 | 请求数（验证/对照） | 原生平均误差 | 修复前 DAG | FCFS DAG | 相对旧 DAG 改善/持平/退化（全部请求） |
|---|---:|---:|---:|---:|---|
| 原23场景 | 311（262/49） | 13.8393% | 5.2344% | 0.0000% | 54/257/0 |
| 原7场景 | 27（18/9） | 4.9767% | 0.0000% | 0.0000% | 0/27/0 |
| 新增8场景 | 128（112/16） | 13.7244% | 9.0170% | 0.0000% | 54/74/0 |

原最坏请求：order-descending / 13，修复前误差 98.8392%，修复后 0.0000%。

误差接近零表示同假设排队模型的一致性，不表示真实 GPU 仿真误差为零。FCFS 改变服务顺序，部分请求预测耗时会变长；逐请求误差均未退化。提交优先级仍为默认兼容策略。

![三版本对照](dag-fcfs-fix.png)

输入身份：

{
  "expanded": {
    "path": "results\\dag\\phase8\\20261119-fcfs-expanded-comparison-01",
    "manifest_sha256": "221ea0a189737c99c916fc674894dd2b9ffc3d3e6fb5bbf2342f1aa48c7e72f4"
  },
  "original": {
    "path": "results\\dag\\phase8\\20261119-fcfs-original-comparison-01",
    "manifest_sha256": "bba8a8eac539207dd9420edfe433b1d8187af34f3131955ea95e41447dee1a83"
  },
  "holdout": {
    "path": "results\\dag\\phase8\\20261119-fcfs-holdout-comparison-01",
    "manifest_sha256": "422bb5627e4d3afca36ecde09f7858a84492b6438bc75bf0fa37b8e517970208"
  }
}
